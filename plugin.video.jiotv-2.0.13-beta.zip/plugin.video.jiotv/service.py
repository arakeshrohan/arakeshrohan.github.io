# -*- coding: utf-8 -*-

from codequick import Script
from codequick.script import Settings
import threading
import socket
import platform
import os
import sys
import time
import stat
import filecmp
import shutil
import urlquick
from kodi_six import xbmc, xbmcaddon, xbmcgui
from resources.lib.monitor import JioTVProxyMonitor
from resources.lib.constants import M3U_SRC, PROXY, ADDON, ADDON_ID, ADDON_PATH
from resources.lib.utils import LOGGEDIN


def get_platform():
    binary_platform = "auto"
    build = xbmc.getInfoLabel("System.BuildVersion")
    kodi_version = int(build.split()[0][:2])

    ret = {
        "auto_arch": sys.maxsize > 2 ** 32 and "64-bit" or "32-bit",
        "arch": sys.maxsize > 2 ** 32 and "x64" or "x86",
        "os": "",
        "version": "",
        "kodi": kodi_version,
        "build": build,
        "fork": True,
        "machine": "",
        "system": "",
        "platform": ""
    }

    try:
        ret["os"] = platform.release()
    except:
        pass

    try:
        ret["machine"] = platform.machine()
    except:
        # Default 'machine' for Android can be 'arm'
        if xbmc.getCondVisibility("system.platform.android"):
            ret["machine"] = "arm"
        pass

    try:
        ret["system"] = platform.system()
    except:
        pass

    try:
        ret["platform"] = platform.platform()
    except:
        pass

    if xbmc.getCondVisibility("system.platform.android"):
        ret["os"] = "android"
        if "arm" in ret["machine"].lower() or "aarch" in ret["machine"].lower():
            ret["arch"] = "arm"
            if "64" in ret["machine"] and ret["auto_arch"] == "64-bit":
                ret["arch"] = "arm64"
    elif xbmc.getCondVisibility("system.platform.linux"):
        ret["os"] = "linux"

        if "aarch" in ret["machine"].lower() or "arm64" in ret["machine"].lower():
            if xbmc.getCondVisibility("system.platform.linux.raspberrypi"):
                ret["arch"] = "armv7"
            elif ret["auto_arch"] == "32-bit":
                ret["arch"] = "armv7"
            elif ret["auto_arch"] == "64-bit":
                ret["arch"] = "arm64"
            # elif platform.architecture()[0].startswith("32"):
            #     ret["arch"] = "armv6"
            else:
                ret["arch"] = "armv7"
        elif "armv7" in ret["machine"]:
            ret["arch"] = "armv7"
        elif "arm" in ret["machine"]:
            cpuarch = ""
            if "aarch" in ret["machine"].lower() or "arm" in ret["machine"].lower():
                info = cpuinfo()
                for proc in info.keys():
                    Script.log("CPU: %s=%s" % (proc, info[proc]))
                    model = ""
                    if "model name" in info[proc]:
                        model = info[proc]["model name"].lower()
                    elif "Processor" in info[proc]:
                        model = info[proc]["Processor"].lower()

                    if model:
                        Script.log("Exploring model: %s" % model)
                        if "aarch" in model or "arm64" in model or "v8l" in model:
                            cpuarch = "arm64"
                        elif "armv7" in model or "v7l" in model:
                            cpuarch = "armv7"
                        break

            if cpuarch:
                Script.log("Using CPU info arch: %s" % cpuarch)
                ret["arch"] = cpuarch
            else:
                ret["arch"] = "armv6"
    elif xbmc.getCondVisibility("system.platform.xbox"):
        ret["os"] = "windows"
        ret["arch"] = "x64"
        ret["fork"] = False
    elif xbmc.getCondVisibility("system.platform.windows"):
        ret["os"] = "windows"
        if ret["machine"].endswith('64'):
            ret["arch"] = "x64"
    elif ret["system"] == "Darwin":
        ret["os"] = "darwin"
        ret["arch"] = "x64"

        if "AppleTV" in ret["platform"]:
            ret["os"] = "ios"
            ret["arch"] = "armv7"
            ret["fork"] = False
            if "64bit" in ret["platform"]:
                ret["arch"] = "arm64"
        elif xbmc.getCondVisibility("system.platform.ios"):
            ret["os"] = "ios"
            ret["arch"] = "armv7"
            ret["fork"] = False
            if "64bit" in ret["platform"]:
                ret["arch"] = "arm64"

    return ret


def cpuinfo():
    cpuinfo = {}
    procinfo = {}
    nprocs = 0
    with open('/proc/cpuinfo') as f:
        for line in f:
            if not line.strip():
                cpuinfo['proc%s' % nprocs] = procinfo
                nprocs = nprocs + 1
            else:
                if len(line.split(':')) == 2:
                    procinfo[line.split(':')[0].strip()] = line.split(':')[
                        1].strip()
                else:
                    procinfo[line.split(':')[0].strip()] = ''
    return cpuinfo


def ensure_exec_perms(file_):
    st = os.stat(file_)
    os.chmod(file_, st.st_mode | stat.S_IEXEC)
    os.chmod(file_, 0755)
    return file_


def android_get_current_appid():
    with open("/proc/%d/cmdline" % os.getpid()) as fp:
        return fp.read().rstrip("\0")


def get_binary():
    binary = "jiotvProxy" + (PLATFORM["os"] == "windows" and ".exe" or "")

    binary_dir = os.path.join(ADDON_PATH, "resources",
                              "bin", "%(os)s_%(arch)s" % PLATFORM)
    if PLATFORM["os"] == "android":
        Script.log("Detected binary folder: %s" % binary_dir)
        binary_dir_legacy = binary_dir.replace(
            "/storage/emulated/0", "/storage/emulated/legacy")
        if os.path.exists(binary_dir_legacy):
            binary_dir = binary_dir_legacy
            Script.log("Using changed binary folder for Android: %s" %
                       binary_dir)

        app_id = android_get_current_appid()
        xbmc_data_path = os.path.join("/data", "data", app_id)
        if not os.path.exists(xbmc_data_path):
            Script.log("%s path does not exist, so using %s as xbmc_data_path" % (
                xbmc_data_path, xbmc.translatePath("special://xbmcbin/")))
            xbmc_data_path = xbmc.translatePath("special://xbmcbin/")

        if not os.path.exists(xbmc_data_path):
            Script.log("%s path does not exist, so using %s as xbmc_data_path" % (
                xbmc_data_path, xbmc.translatePath("special://masterprofile/")))
            xbmc_data_path = xbmc.translatePath("special://masterprofile/")

        dest_binary_dir = os.path.join(
            xbmc_data_path, "files", ADDON_ID, "bin", "%(os)s_%(arch)s" % PLATFORM)
    else:
        dest_binary_dir = os.path.join(xbmc.translatePath(
            ADDON.getAddonInfo("profile")), "bin", "%(os)s_%(arch)s" % PLATFORM)

    binary_path = os.path.join(binary_dir, binary)
    dest_binary_path = os.path.join(dest_binary_dir, binary)

    Script.log("Binary detection. Source: %s, Destination: %s" %
               (binary_path, dest_binary_path), lvl=Script.INFO)

    if not os.path.exists(binary_path):
        Script.notify(
            "Jiotv Service", "Unable to find Jiotv Proxy binary[CR]Required platform:" + " %(os)s_%(arch)s" % PLATFORM)
        # dialog_ok("LOCALIZE[30347];;" + "%(os)s_%(arch)s" % PLATFORM)
        # system_information()
        try:
            Script.log("Source directory (%s):\n%s" %
                       (binary_dir, os.listdir(os.path.join(binary_dir, ".."))), lvl=Script.INFO)
            Script.log("Destination directory (%s):\n%s" % (
                dest_binary_dir, os.listdir(os.path.join(dest_binary_dir, ".."))), lvl=Script.INFO)
        except Exception:
            pass
        return False, False

    if os.path.isdir(dest_binary_path):
        Script.log(
            "Destination path is a directory, expected previous binary file, removing...", lvl=Script.WARNING)
        try:
            shutil.rmtree(dest_binary_path)
        except Exception as e:
            Script.log("Unable to remove destination path for update: %s" %
                       e, lvl=Script.ERROR)
            # system_information()
            return False, False

    if not os.path.exists(dest_binary_path) or not os.path.exists(binary_path) or not filecmp.cmp(dest_binary_path, binary_path, shallow=True):
        Script.log("Updating proxy daemon...", lvl=Script.INFO)
        try:
            os.makedirs(dest_binary_dir)
        except OSError:
            pass
        try:
            shutil.rmtree(dest_binary_dir)
        except Exception as e:
            Script.log("Unable to remove destination path for update: %s" %
                       e, lvl=Script.ERROR)
            # system_information()
            pass
        try:
            shutil.copytree(binary_dir, dest_binary_dir)
        except Exception as e:
            Script.log("Unable to copy to destination path for update: %s" %
                       e, lvl=Script.ERROR)
            # system_information()
            return False, False

    # Clean stale files in the directory, as this can cause headaches on
    # Android when they are unreachable
    dest_files = set(os.listdir(dest_binary_dir))
    orig_files = set(os.listdir(binary_dir))
    dest_files.discard("proxy.db")
    Script.log("Deleting stale files %s" %
               (dest_files - orig_files), lvl=Script.INFO)
    for file_ in (dest_files - orig_files):
        path = os.path.join(dest_binary_dir, file_)
        if os.path.isdir(path):
            shutil.rmtree(path)
        else:
            os.remove(path)

    Script.log("Binary detection: [ Source: %s, Destination: %s ]" % (
        binary_path, dest_binary_path), lvl=Script.INFO)
    return dest_binary_dir, ensure_exec_perms(dest_binary_path)


PLATFORM = get_platform()
proxy_dir = ""
try:
    import subprocess
    hasSubprocess = True
    if not PLATFORM["fork"]:
        hasSubprocess = False
except:
    hasSubprocess = False


def getShortPath(path):
    if PLATFORM["os"] == "windows":
        return getWindowsShortPath(path)
    return path


def getWindowsShortPath(path):
    try:
        import ctypes
        import ctypes.wintypes

        ctypes.windll.kernel32.GetShortPathNameW.argtypes = [
            ctypes.wintypes.LPCWSTR,  # lpszLongPath
            ctypes.wintypes.LPWSTR,  # lpszShortPath
            ctypes.wintypes.DWORD  # cchBuffer
        ]
        ctypes.windll.kernel32.GetShortPathNameW.restype = ctypes.wintypes.DWORD

        # adjust buffer size, if necessary
        buf = ctypes.create_unicode_buffer(1024)
        ctypes.windll.kernel32.GetShortPathNameW(path, buf, len(buf))

        return buf.value
    except:
        return path


def clear_fd_inherit_flags():
    # Ensure the spawned proxy binary doesn't inherit open files from Kodi
    # which can break things like addon updates. [WINDOWS ONLY]
    try:
        from ctypes import windll
        import six
        HANDLE_RANGE = six.moves.xrange(0, 65536)
        HANDLE_FLAG_INHERIT = 1
        FILE_TYPE_DISK = 1

        for hd in HANDLE_RANGE:
            if windll.kernel32.GetFileType(hd) == FILE_TYPE_DISK:
                if not windll.kernel32.SetHandleInformation(hd, HANDLE_FLAG_INHERIT, 0):
                    Script.log(
                        "Error clearing inherit flag, disk file handle %x" % hd, lvl=Script.ERROR)
    except:
        pass


def start_proxyd(**kwargs):
    global proxy_dir
    proxy_dir, proxy_binary = get_binary()

    Script.log("Binary dir: %s, item: %s " %
               (proxy_dir, proxy_binary), lvl=Script.INFO)
    if proxy_dir is False or proxy_binary is False:
        return False

    lockfile = os.path.join(ADDON_PATH, ".lockfile")
    if os.path.exists(lockfile):
        Script.log("Existing process found from lockfile, killing...",
                   lvl=Script.WARNING)
        try:
            with open(lockfile) as lf:
                pid = int(lf.read().rstrip(" \t\r\n\0"))
            os.kill(pid, 9)
        except OSError as e:
            if e.errno != 3:
                # Ignore:   OSError: [Errno 3] No such process
                Script.log(repr(e), lvl=Script.ERROR)
        except Exception as e:
            Script.log(repr(e), lvl=Script.ERROR)

        if PLATFORM["os"] == "windows":
            try:
                library_lockfile = os.path.join(xbmc.translatePath(
                    ADDON.getAddonInfo("profile")).decode('utf-8'), "library.db.lock")
                Script.log("Removing library.db.lock file at %s ..." %
                           library_lockfile, lvl=Script.WARNING)
                os.remove(library_lockfile)
            except Exception as e:
                Script.log(repr(e), lvl=Script.ERROR)

    SW_HIDE = 0
    STARTF_USESHOWWINDOW = 1

    args = [proxy_binary]
    kwargs["cwd"] = proxy_dir
    if os.path.exists(os.path.join(xbmc.translatePath('special://home/addons/plugin.video.jiotv/resources/extra').decode('utf-8'), 'proxy.db')) and not os.path.exists(os.path.join(xbmc.translatePath(
            ADDON.getAddonInfo("profile")).decode('utf-8'), "proxy.db")):
        shutil.copyfile(os.path.join(xbmc.translatePath('special://home/addons/plugin.video.jiotv/resources/extra').decode('utf-8'), 'proxy.db'), os.path.join(xbmc.translatePath(
            ADDON.getAddonInfo("profile")).decode('utf-8'), "proxy.db"))

    if PLATFORM["os"] == "windows":
        args[0] = getWindowsShortPath(proxy_binary)
        kwargs["cwd"] = getWindowsShortPath(proxy_dir)
        si = subprocess.STARTUPINFO()
        si.dwFlags = STARTF_USESHOWWINDOW
        si.wShowWindow = SW_HIDE
        clear_fd_inherit_flags()
        kwargs["startupinfo"] = si
    else:
        env = os.environ.copy()
        if env.get("TZ"):
            env["TZ"] = env.get("TZ").replace(":", "")
        kwargs["close_fds"] = True
        kwargs["env"] = env
    wait_counter = 1
    Script.log("Checking for visible")
    while xbmc.getCondVisibility('Window.IsVisible(10140)') or xbmc.getCondVisibility('Window.IsActive(10140)'):
        if wait_counter == 1:
            Script.log(
                'Add-on settings currently opened, waiting before starting...', lvl=Script.INFO)
        if wait_counter > 300:
            break
        time.sleep(1)
        wait_counter += 1

    Script.log("proxyd: start args: %s, kw: %s" %
               (args, kwargs), lvl=Script.INFO)

    if hasSubprocess:
        return subprocess.Popen(args, **kwargs)
    return False


def wait_for_abortRequested(proc, monitor):
    monitor.closing.wait()
    Script.log("proxyd: exiting proxyd daemon", lvl=Script.INFO)
    try:
        if proc is not None:
            proc.terminate()
    except OSError:
        pass  # Process already exited, nothing to terminate
    Script.log("proxyd: proxyd daemon exited", lvl=Script.INFO)


def proxyd_thread(monitor):
    crash_count = 0
    try:
        while not xbmc.abortRequested:
            Script.log("proxyd: starting proxyd", lvl=Script.INFO)
            proc = None
            if hasSubprocess:
                proc = start_proxyd(
                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
                if not proc:
                    break
            else:
                Script.log(
                    "proxyd: current system is unable to run the binary", lvl=Script.INFO)
                break

            threading.Thread(target=wait_for_abortRequested,
                             args=[proc, monitor]).start()

            if not hasSubprocess:
                break

            if PLATFORM["os"] == "windows":
                while proc.poll() is None:
                    Script.log(proc.stdout.readline(), lvl=Script.INFO)
            else:
                # Kodi hangs on some Android (sigh...) systems when doing a blocking
                # read. We count on the fact that proxy daemon flushes its log
                # output on \n, creating a pretty clean output
                import fcntl
                import select
                fd = proc.stdout.fileno()
                fl = fcntl.fcntl(fd, fcntl.F_GETFL)
                fcntl.fcntl(fd, fcntl.F_SETFL, fl | os.O_NONBLOCK)
                while proc.poll() is None:
                    try:
                        to_read, _, _ = select.select([proc.stdout], [], [])
                        for ro in to_read:
                            line = ro.readline()
                            if line == "":  # write end is closed
                                break
                            Script.log(line, lvl=Script.INFO)
                    except IOError:
                        time.sleep(1)  # nothing to read, sleep

            if proc.returncode == 0 or xbmc.abortRequested:
                break

            if proc.returncode == 5:
                Script.notify("Jiotv Service", "Reloading configuration...")
            else:
                crash_count += 1
                if os.path.exists(os.path.join(xbmc.translatePath(ADDON.getAddonInfo("profile")).decode('utf-8'), 'jiotvProxy.log')):
                    shutil.copyfile(os.path.join(xbmc.translatePath(ADDON.getAddonInfo("profile")).decode(
                        'utf-8'), 'jiotvProxy.log'), os.path.join(xbmc.translatePath(ADDON.getAddonInfo("profile")).decode('utf-8'), "crash.log"))
                Script.notify("Jiotv Service",
                              "Service has crashed, restarting...")

            # system_information()
            time.sleep(5)
            if crash_count >= 3:
                Script.notify("Jiotv Service",
                              "Crashed too many times, aborting...")
                break

    except Exception as e:
        import traceback
        map(Script.log, traceback.format_exc().split("\n"), lvl=Script.INFO)
        Script.notify("Jiotv Service", "%s: %s" %
                      ("Proxy error", repr(e).encode('utf-8')))
        raise


monitor = JioTVProxyMonitor()
t = threading.Thread(target=proxyd_thread, args=[monitor])
t.daemon = True
t.start()

if not Settings.get_boolean("popup"):
    xbmcgui.Dialog().ok("JioTV Notification",
                        "Now you can watch your favorite channel from other external players.[CR]Use this m3u link [B]http://%s:48996/playlist.m3u[/B] [CR][I](Note: Kodi must be running in background or run proxy binary mannualy.)[/I] [CR][CR]If you like this add-on then consider supporting from [B]https://kodi.botallen.com[/B] [CR][CR]Github: [B]https://github.com/botallen/repository.botallen[/B] [CR]Discord: [B]https://botallen.com/discord[/B] [CR][CR][I]You can disable this popup from settings[/I]" % socket.gethostbyname(socket.gethostname()))

# Wait for proxy to start
a_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
while a_socket.connect_ex(("127.0.0.1", 48996)) != 0:
    time.sleep(.2)
Script.notify('Jiotv Service', 'Jiotv Background Service Started')
a_socket.close()
try:
    LOGGEDIN = urlquick.get(PROXY + "/login", max_age=-1,
                            raise_for_status=False).status_code == 200
except:
    LOGGEDIN = False
# XBMC loop
next_check = time.time() - 100
m3uChecked = False
while not monitor.abortRequested():
    if LOGGEDIN and not os.path.exists(M3U_SRC) and not m3uChecked:
        m3uChecked = True
        xbmc.executebuiltin(
            "RunPlugin(plugin://plugin.video.jiotv/resources/lib/main/m3ugen/)")
        if xbmcgui.Dialog().yesno('Jiotv PVR Setup', 'Do you want to setup PVR automatically?'):
            xbmc.executebuiltin(
                "RunPlugin(plugin://plugin.video.jiotv/resources/lib/main/pvrsetup/)")
    if not LOGGEDIN:
        try:
            LOGGEDIN = urlquick.get(PROXY + "/login", max_age=-1,
                                    raise_for_status=False).status_code == 200
        except:
            LOGGEDIN = False
    xbmc.sleep(1000)

Script.log("jiotvProxy: exiting proxyd", lvl=Script.INFO)
